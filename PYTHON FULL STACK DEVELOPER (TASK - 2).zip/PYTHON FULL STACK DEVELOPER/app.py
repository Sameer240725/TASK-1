from flask import Flask, render_template, request, redirect, session, flash
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3

app = Flask(__name__)
app.secret_key = "maincrafts_secret_key"


# ---------------- DATABASE ---------------- #

def get_connection():
    conn = sqlite3.connect("database.db")
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_connection()
    cursor = conn.cursor()

    # Existing User Management Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL,
        age INTEGER NOT NULL
    )
    """)

    # Authentication Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS accounts(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL
    )
    """)

    conn.commit()
    conn.close()


init_db()


# ---------------- HOME ---------------- #

@app.route("/")
def home():

    if "username" not in session:
        return redirect("/login")

    conn = get_connection()
    users = conn.execute("SELECT * FROM users").fetchall()
    conn.close()

    return render_template(
        "index.html",
        users=users,
        username=session["username"]
    )


# ---------------- ADD USER ---------------- #

@app.route("/add", methods=["POST"])
def add_user():

    if "username" not in session:
        return redirect("/login")

    name = request.form["name"]
    email = request.form["email"]
    age = request.form["age"]

    conn = get_connection()

    conn.execute(
        "INSERT INTO users(name,email,age) VALUES(?,?,?)",
        (name, email, age)
    )

    conn.commit()
    conn.close()

    return redirect("/")


# ---------------- EDIT USER ---------------- #

@app.route("/edit/<int:user_id>", methods=["GET", "POST"])
def edit_user(user_id):

    if "username" not in session:
        return redirect("/login")

    conn = get_connection()

    if request.method == "POST":
        name = request.form["name"]
        email = request.form["email"]
        age = request.form["age"]

        conn.execute(
            "UPDATE users SET name=?, email=?, age=? WHERE id=?",
            (name, email, age, user_id)
        )

        conn.commit()
        conn.close()

        return redirect("/")

    user = conn.execute(
        "SELECT * FROM users WHERE id=?",
        (user_id,)
    ).fetchone()

    conn.close()

    if not user:
        flash("User not found")
        return redirect("/")

    return render_template("edit.html", user=user)


# ---------------- DELETE USER ---------------- #

@app.route("/delete/<int:user_id>")
def delete_user(user_id):

    if "username" not in session:
        return redirect("/login")

    conn = get_connection()
    conn.execute("DELETE FROM users WHERE id=?", (user_id,))
    conn.commit()
    conn.close()

    return redirect("/")


# ---------------- REGISTER ---------------- #

@app.route("/register", methods=["GET", "POST"])
def register():

    if request.method == "POST":

        username = request.form["username"]
        password = request.form["password"]

        hashed_password = generate_password_hash(password)

        conn = get_connection()

        try:

            conn.execute(
                "INSERT INTO accounts(username,password) VALUES(?,?)",
                (username, hashed_password)
            )

            conn.commit()

            flash("Registration Successful")

            return redirect("/login")

        except:

            flash("Username already exists")

        finally:

            conn.close()

    return render_template("register.html")


# ---------------- LOGIN ---------------- #

@app.route("/login", methods=["GET", "POST"])
def login():

    if request.method == "POST":

        username = request.form["username"]
        password = request.form["password"]

        conn = get_connection()

        user = conn.execute(
            "SELECT * FROM accounts WHERE username=?",
            (username,)
        ).fetchone()

        conn.close()

        if user:

            if check_password_hash(user["password"], password):

                session["username"] = username

                return redirect("/dashboard")

        flash("Invalid Username or Password")

    return render_template("login.html")


# ---------------- DASHBOARD ---------------- #

@app.route("/dashboard")
def dashboard():

    if "username" not in session:
        return redirect("/login")

    return render_template(
        "dashboard.html",
        username=session["username"]
    )


# ---------------- LOGOUT ---------------- #

@app.route("/logout")
def logout():

    session.pop("username", None)

    return redirect("/login")


# ---------------- RUN ---------------- #

if __name__ == "__main__":
    app.run(debug=True)