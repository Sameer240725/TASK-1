# User Management Web Application

## Objective

Build a web application to add and view users using Flask and SQLite.

## Technologies Used

* Python
* Flask
* HTML
* CSS
* SQLite

## Features

* Add User
* View Users
* Store Data Permanently

## Project Flow

1. User enters details.
2. Form sends data to Flask.
3. Flask stores data in SQLite database.
4. Data is fetched from database.
5. Users are displayed in a table.

## Tools Used

* VS Code
* SQLite
* Browser
